//product of two number as a string
function prod(num1, num2) {
    const n1 = num1.length, n2 = num2.length;
    const result = new Array(n1 + n2).fill(0);
  
    for (let i = n1 - 1; i >= 0; i--) {
      for (let j = n2 - 1; j >= 0; j--) {
        const product = parseInt(num1[i]) * parseInt(num2[j]);
        const p1 = i + j, p2 = i + j + 1;
        const sum = product + result[p2];
        result[p1] += Math.floor(sum / 10);
        result[p2] = sum % 10;
      }
    }
  
    while (result.length > 1 && result[0] === 0) {
      result.shift();
    }
  
    return result.join('');
  }
  const num1 = '123';
  const num2 = '456';
  const product = prod(num1, num2);
  console.log(product);
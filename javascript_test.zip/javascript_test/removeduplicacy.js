//remove duplicacy of array
const arr = [1,2,3,1,3,4,5,6,6,7,5];
const newarr = [];

for (let i = 0; i < arr.length; i++) {
  if (!newrr.includes(arr[i])) {
    newarr.push(arr[i]);
  }
}

console.log(newarr); 

//take roman number as a input and return output an interger

function romanToInt(roman) {
    const romanValues = {
      "I": 1,
      "V": 5,
      "X": 10,
      "L": 50,
      "C": 100,
      "D": 500,
      "M": 1000
    };
    let result = 0;
    let previous = 0;
    
    for (let i = roman.length - 1; i >= 0; i--) {
      const current = romanValues[roman[i]];
      if (current >= previous) {
        result += current;
      } else {
        result -= current;
      }
      previous = current;
    }
    
    return result;
  }
  const romanNumeral = "LVIII";
  const integer = romanToInt(romanNumeral);
  console.log(integer); 
    